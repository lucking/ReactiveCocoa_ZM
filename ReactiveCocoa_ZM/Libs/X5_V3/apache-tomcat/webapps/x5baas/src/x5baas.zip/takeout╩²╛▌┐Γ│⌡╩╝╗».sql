-- --------------------------------------------------------
-- 主机                            :127.0.0.1
-- 服务器版本                         :5.0.67-community-log - MySQL Community Edition (GPL)
-- 服务器操作系统                       :Win32
-- HeidiSQL 版本                   :7.0.0.4278
-- 创建                            :2014-11-05 16:22:25
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 导出  表 takeout.takeout_food 结构
CREATE TABLE IF NOT EXISTS `takeout_food` (
  `fID` varchar(50) NOT NULL COMMENT '主键',
  `fName` varchar(50) default NULL COMMENT '套餐',
  `fPrice` decimal(10,2) default NULL COMMENT '单价',
  `fDescription` varchar(100) default NULL,
  `fImage` varchar(100) default NULL,
  PRIMARY KEY  (`fID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  takeout.takeout_food 的数据: ~8 rows ((大约))
/*!40000 ALTER TABLE `takeout_food` DISABLE KEYS */;
INSERT INTO `takeout_food` (`fID`, `fName`, `fPrice`, `fDescription`, `fImage`) VALUES
	('001', '老北京炸酱面', 20.00, '苏格兰打卤面，大杯可乐', '1.jpg'),
	('002', '宫爆鸡丁', 25.00, '宫爆鸡丁一份，两碗米饭，蛋花汤', '2.jpg'),
	('003', '剁椒鱼头套餐', 36.00, '剁椒鱼头，白菜豆腐汤，四碗面条，可口凉菜', '3.jpg'),
	('004', '老北京烤鸭套餐', 45.00, '北京烤鸭，四碗米饭，大杯可乐四桶，鸡蛋汤', '4.jpg'),
	('005', '土豆炖牛肉套餐', 35.00, '土豆炖牛肉一份，米饭四碗，可口可乐，凉菜', '5.jpg'),
	('006', '鱼香肉丝盖饭', 15.00, '现炒鱼香肉丝', '6.jpg'),
	('007', '尖椒肉丝盖饭', 15.00, '绿色尖椒', '7.jpg'),
	('008', '家常肉饼', 10.00, '肉饼三个', '8.jpg');
/*!40000 ALTER TABLE `takeout_food` ENABLE KEYS */;


-- 导出  表 takeout.takeout_order 结构
CREATE TABLE IF NOT EXISTS `takeout_order` (
  `fID` varchar(50) NOT NULL,
  `fCreateTime` datetime default NULL COMMENT '下单时间',
  `fContent` varchar(200) default NULL COMMENT '订单内容',
  `fSum` decimal(10,2) default NULL COMMENT '合计金额',
  `fUserID` varchar(50) default NULL COMMENT '下单人',
  `fUserName` varchar(50) default NULL,
  `fPhoneNumber` varchar(20) default NULL,
  `fAddress` varchar(200) default NULL COMMENT '订单地址',
  PRIMARY KEY  (`fID`),
  INDEX `order_user_idx` (`fUserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  takeout.takeout_order 的数据: ~5 rows ((大约))
/*!40000 ALTER TABLE `takeout_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `takeout_order` ENABLE KEYS */;


-- 导出  表 takeout.takeout_user 结构
CREATE TABLE IF NOT EXISTS `takeout_user` (
  `fID` varchar(50) NOT NULL COMMENT '机器码',
  `fName` varchar(50) default NULL COMMENT '姓名',
  `fPhoneNumber` varchar(20) default NULL COMMENT '电话',
  `fAddress` varchar(200) default NULL COMMENT '地址',
  PRIMARY KEY  (`fID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  takeout.takeout_user 的数据: ~2 rows ((大约))
/*!40000 ALTER TABLE `takeout_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `takeout_user` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
