package x5.baas.util;

import org.codehaus.jackson.jaxrs.JacksonJsonProvider;
import org.glassfish.jersey.server.ResourceConfig;

public class JerseyApplication extends ResourceConfig {
	public JerseyApplication() {
		// 注册JSON转换器
		register(JacksonJsonProvider.class);
		// 服务类所在的包路径
		packages("x5.baas.services");
	}
}
