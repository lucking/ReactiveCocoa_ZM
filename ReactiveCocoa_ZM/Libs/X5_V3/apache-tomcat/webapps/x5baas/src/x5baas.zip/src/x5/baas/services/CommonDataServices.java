package x5.baas.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import x5.baas.util.HibernateUtil;

@Path("/")
public class CommonDataServices {
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String test() {
		return "ok";
	}
	
	/**
	 * 通用查询，支持一次多个查询结果
	 * @param querys 
	 * 		外层map的key是queryName，value是params
	 * @return
	 * 		key是queryName，value是查询结果
	 */
	@SuppressWarnings("unchecked")
	@POST
	@Path("/commonQuery")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Map<String, List<Object>> query(Map<String, Map<String, Object>> querys) {
		Map<String, List<Object>> result = new HashMap<String, List<Object>>();
		Session session = HibernateUtil.openSession();
		try {
			for (String queryName : querys.keySet()) {
				Query query = session.getNamedQuery(queryName);
				Map<String, Object> params = querys.get(queryName);
				query.setProperties(params);
				query.setFirstResult(0);
				query.setMaxResults(20);
				result.put(queryName, query.list());
			}
		} finally {
			session.close();
		} 
		return result; 
	}
	
	/**
	 * 通用保存，支持一次保存多个数据
	 * @param saves
	 * 		key : 实体名称
	 * 		value : delta 
	 * 			key : recordState new|edit|delete|none
	 * 			value : maps
	 */
	@POST
	@Path("/commonSave")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public void save(Map<String, Map<String, List<Map<String, Object>>>> saves) {
		Session session = HibernateUtil.openSession();
		try {
			Transaction tran = session.beginTransaction();
			try {
				for (String entityName : saves.keySet()) {
					Map<String, List<Map<String, Object>>> delta = saves.get(entityName);
					saveDelta(session, entityName, delta);
				}
				tran.commit();
			} catch (Exception e) {
				tran.rollback();
				throw new RuntimeException(e);
			}
		} finally {
			session.close();
		}
	}
	
	private void saveMaps(Session session, String entityName, String recordState, List<Map<String, Object>> maps) {
		if ("new".equals(recordState)) {
			for (Map<String, Object> map : maps) {
				session.save(entityName, map);
			}
		} else if ("edit".equals(recordState)) {
			for (Map<String, Object> map : maps) {
				session.update(entityName, map);
			}
		} else if ("delete".equals(recordState)) {
			for (Map<String, Object> map : maps) {
				session.delete(entityName, map);
			}
		}
	}
	
	private void saveDelta(Session session, String entityName, Map<String, List<Map<String, Object>>> delta) {
		for (String recordState : delta.keySet()) {
			List<Map<String, Object>> maps = delta.get(recordState);
			saveMaps(session, entityName, recordState, maps);
		}
	}
	
}
